var express = require('express');
var router = express.Router();

//var sql = require("mssql");

    // config for your database
var config = {
	user: 'teste',
	password: 'teste',
	server: 'DESKTOP-9EQHR6F', 
	database: 'master' 
};
/* GET home page. */
router.get('/', function(req, res, next) {
    //res.sendFile('index2.html');
	console.log("teste");

    // connect to your database
    sql.connect(config, function (err) {
		
		console.log("conectou");
        if (err) console.log(err);
        // create Request object
        var request = new sql.Request();
           
        // query to the database and get the records
        request.query('select * from Cliente', function (err, recordset) {
            
            if (err) console.log(err)
			console.log(recordset);
            // send records as a response
            res.send(recordset);
            
        });
    });
});

router.get('/Cliente', function (req, res, next) {
    res.sendFile('CadastroPessoa.html');
});

router.get('/Balada', function (req, res, next) {
    res.sendFile('CadastroBalada.html');
});

router.get('/Evento', function (req, res, next) {
    res.sendFile('CadastroEvento.html');
});

module.exports = router;
